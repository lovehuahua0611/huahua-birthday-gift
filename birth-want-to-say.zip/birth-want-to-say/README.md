# 这是什么东西？

> 源码来自 https://github.com/AJLoveChina/birthday 基本没做改动
>

一个女朋友生日的程序员解决方案，支持便捷的内容配置，急速替换为自己想要的内容，点击下方链接预览效果。

- 国内用户访问：[https://sg.chenjianhui.site/girlfriend-gift-collection/birth-want-to-say/](https://sg.chenjianhui.site/girlfriend-gift-collection/birth-want-to-say/)
- Github Pages: [https://calebman.github.io/girlfriend-gift-collection/birth-want-to-say/](https://calebman.github.io/girlfriend-gift-collection/birth-want-to-say/)
# 如何修改为自己的内容

一、修改配置内容

修改 birth-want-to-say 目录下的 config.js 文件，达到预期效果

- texts: 代表播放内容
- imgs: 与内容对应的图片，通过下标一一对应

二、部署静态资源

直接部署 birth-want-to-say 到静态文件服务器即可